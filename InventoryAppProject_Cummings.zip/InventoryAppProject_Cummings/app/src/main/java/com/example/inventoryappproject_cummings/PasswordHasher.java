package com.example.inventoryappproject_cummings;

import android.util.Base64;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.spec.InvalidKeySpecException;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

/**
 * Turns passwords into salted hashes so the database never holds a
 * readable password. Uses PBKDF2, which is built into Android and works
 * on every version this app supports (API 24 and up).
 */
public final class PasswordHasher {

    private static final String ALGORITHM = "PBKDF2WithHmacSHA1";
    private static final int ITERATIONS = 10000;
    private static final int KEY_LENGTH_BITS = 256;
    private static final int SALT_LENGTH_BYTES = 16;

    // Utility class: no instances needed
    private PasswordHasher() {
    }

    /** Creates a random salt so two users with the same password get different hashes. */
    public static String generateSalt() {
        byte[] salt = new byte[SALT_LENGTH_BYTES];
        new SecureRandom().nextBytes(salt);
        return Base64.encodeToString(salt, Base64.NO_WRAP);
    }

    /** Hashes a password with the given salt. */
    public static String hash(String password, String salt) {
        PBEKeySpec spec = new PBEKeySpec(password.toCharArray(),
                Base64.decode(salt, Base64.NO_WRAP), ITERATIONS, KEY_LENGTH_BITS);
        try {
            byte[] hash = SecretKeyFactory.getInstance(ALGORITHM).generateSecret(spec).getEncoded();
            return Base64.encodeToString(hash, Base64.NO_WRAP);
        } catch (NoSuchAlgorithmException | InvalidKeySpecException e) {
            // PBKDF2 ships with Android, so this should never happen on a real device
            throw new IllegalStateException("Password hashing is unavailable", e);
        } finally {
            spec.clearPassword(); // Wipe the password copy from memory
        }
    }

    /** Checks a typed password against a stored hash. */
    public static boolean matches(String password, String salt, String storedHash) {
        String attemptHash = hash(password, salt);
        // Constant-time compare so timing can't leak how close a guess was
        return MessageDigest.isEqual(
                attemptHash.getBytes(), storedHash.getBytes());
    }
}