package com.example.inventoryappproject_cummings;

import android.content.Intent;
import android.os.Bundle;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

/**
 * First screen of the app. Checks a username and password against the
 * users table, or creates a new account for first-time users.
 */
public class LoginActivity extends AppCompatActivity {

    private DatabaseHelper databaseHelper;
    private TextInputLayout layoutUsername;
    private TextInputLayout layoutPassword;
    private TextInputEditText editUsername;
    private TextInputEditText editPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_login);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        databaseHelper = DatabaseHelper.getInstance(this);
        layoutUsername = findViewById(R.id.layoutUsername);
        layoutPassword = findViewById(R.id.layoutPassword);
        editUsername = findViewById(R.id.editUsername);
        editPassword = findViewById(R.id.editPassword);
        Button buttonLogin = findViewById(R.id.buttonLogin);
        Button buttonCreateAccount = findViewById(R.id.buttonCreateAccount);

        buttonLogin.setOnClickListener(v -> attemptLogin());
        buttonCreateAccount.setOnClickListener(v -> attemptCreateAccount());

        // Pressing "Done" on the keyboard in the password box logs in
        editPassword.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                attemptLogin();
                return true;
            }
            return false;
        });
    }

    /** Checks the typed credentials against the database. */
    private void attemptLogin() {
        String username = InputValidator.clean(editUsername.getText());
        String password = editPassword.getText() == null ? "" : editPassword.getText().toString();

        if (!fieldsFilledIn(username, password)) {
            return;
        }

        if (databaseHelper.checkLogin(username, password)) {
            openInventory();
        } else {
            // Same message for wrong username or wrong password so we don't
            // reveal which usernames exist
            layoutPassword.setError(getString(R.string.error_login_failed));
        }
    }

    /** Saves a brand-new account, then logs the user straight in. */
    private void attemptCreateAccount() {
        String username = InputValidator.clean(editUsername.getText());
        String password = editPassword.getText() == null ? "" : editPassword.getText().toString();

        if (!fieldsFilledIn(username, password)) {
            return;
        }
        if (!InputValidator.isValidUsername(username)) {
            layoutUsername.setError(getString(R.string.error_username_short,
                    InputValidator.MIN_USERNAME_LENGTH));
            return;
        }
        if (!InputValidator.isValidPassword(password)) {
            layoutPassword.setError(getString(R.string.error_password_short,
                    InputValidator.MIN_PASSWORD_LENGTH));
            return;
        }
        if (databaseHelper.usernameExists(username)) {
            layoutUsername.setError(getString(R.string.error_username_taken));
            return;
        }

        if (databaseHelper.createUser(username, password)) {
            Toast.makeText(this, getString(R.string.toast_account_created, username),
                    Toast.LENGTH_SHORT).show();
            openInventory();
        } else {
            Toast.makeText(this, R.string.toast_account_failed, Toast.LENGTH_SHORT).show();
        }
    }

    /** Clears old errors and flags any empty box. Returns true if both are filled. */
    private boolean fieldsFilledIn(String username, String password) {
        layoutUsername.setError(null);
        layoutPassword.setError(null);

        boolean valid = true;
        if (username.isEmpty()) {
            layoutUsername.setError(getString(R.string.error_username_required));
            valid = false;
        }
        if (password.isEmpty()) {
            layoutPassword.setError(getString(R.string.error_password_required));
            valid = false;
        }
        return valid;
    }

    private void openInventory() {
        startActivity(new Intent(this, InventoryActivity.class));
        finish(); // Back button from the grid shouldn't land on the login screen
    }
}