package com.example.inventoryappproject_cummings;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

/**
 * Binds inventory items to the grid rows.
 *
 * The adapter only handles display. When the user taps +, -, delete, or
 * the row itself, it reports back through {@link OnItemActionListener}
 * and the Activity decides what to do with the database.
 */
public class InventoryAdapter extends RecyclerView.Adapter<InventoryAdapter.ViewHolder> {

    /** Callbacks for every action a user can take on a row. */
    public interface OnItemActionListener {
        void onQuantityChangeRequested(InventoryItem item, int newQuantity);

        void onDeleteRequested(InventoryItem item);

        void onEditRequested(InventoryItem item);
    }

    private final List<InventoryItem> items = new ArrayList<>();
    private final OnItemActionListener listener;

    public InventoryAdapter(OnItemActionListener listener) {
        this.listener = listener;
    }

    /** Replaces the whole list, used after loading from the database. */
    public void setItems(List<InventoryItem> newItems) {
        items.clear();
        items.addAll(newItems);
        notifyDataSetChanged();
    }

    /** Redraws one row after its data changed. */
    public void refreshItem(InventoryItem item) {
        int position = items.indexOf(item);
        if (position != RecyclerView.NO_POSITION) {
            notifyItemChanged(position);
        }
    }

    /** Removes one row with the standard slide-out animation. */
    public void removeItem(InventoryItem item) {
        int position = items.indexOf(item);
        if (position != RecyclerView.NO_POSITION) {
            items.remove(position);
            notifyItemRemoved(position);
        }
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_inventory, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        InventoryItem item = items.get(position);
        holder.textItemName.setText(item.getName());
        holder.textQuantity.setText(String.valueOf(item.getQuantity()));

        // Out of stock shows in red so it stands out
        int qtyColor = item.isOutOfStock() ? R.color.alert_red : R.color.white;
        holder.textQuantity.setTextColor(
                ContextCompat.getColor(holder.itemView.getContext(), qtyColor));

        // Can't go below zero, so the minus button is disabled at 0
        holder.buttonDecrease.setEnabled(!item.isOutOfStock());
        holder.buttonDecrease.setAlpha(item.isOutOfStock() ? 0.3f : 1f);

        holder.buttonIncrease.setOnClickListener(v ->
                listener.onQuantityChangeRequested(item, item.getQuantity() + 1));
        holder.buttonDecrease.setOnClickListener(v ->
                listener.onQuantityChangeRequested(item, item.getQuantity() - 1));
        holder.buttonDelete.setOnClickListener(v -> listener.onDeleteRequested(item));
        holder.itemView.setOnClickListener(v -> listener.onEditRequested(item));
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        final TextView textItemName;
        final TextView textQuantity;
        final ImageButton buttonDecrease;
        final ImageButton buttonIncrease;
        final ImageButton buttonDelete;

        ViewHolder(@NonNull View itemView) {
            super(itemView);
            textItemName = itemView.findViewById(R.id.textItemName);
            textQuantity = itemView.findViewById(R.id.textQuantity);
            buttonDecrease = itemView.findViewById(R.id.buttonDecrease);
            buttonIncrease = itemView.findViewById(R.id.buttonIncrease);
            buttonDelete = itemView.findViewById(R.id.buttonDelete);
        }
    }
}