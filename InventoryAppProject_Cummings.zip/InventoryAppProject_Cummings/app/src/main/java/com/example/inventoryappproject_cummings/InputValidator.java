package com.example.inventoryappproject_cummings;

import android.text.TextUtils;

/**
 * Input rules shared by more than one screen, kept in one place so the
 * login screen, Add Item screen, and edit dialog all agree.
 */
public final class InputValidator {

    public static final int MIN_USERNAME_LENGTH = 3;
    public static final int MIN_PASSWORD_LENGTH = 6;
    public static final int MAX_QUANTITY = 999999; // Matches the 6-digit limit on the input field

    /** Returned by {@link #parseQuantity(String)} when the text isn't a usable quantity. */
    public static final int INVALID_QUANTITY = -1;

    // Utility class: no instances needed
    private InputValidator() {
    }

    /** Safely pulls trimmed text from a possibly-null field value. */
    public static String clean(CharSequence text) {
        return text == null ? "" : text.toString().trim();
    }

    public static boolean isValidUsername(String username) {
        return username.length() >= MIN_USERNAME_LENGTH;
    }

    public static boolean isValidPassword(String password) {
        return password.length() >= MIN_PASSWORD_LENGTH;
    }

    /**
     * Converts quantity text into a number between 0 and MAX_QUANTITY.
     *
     * @return the quantity, or INVALID_QUANTITY if blank, not a number, or out of range
     */
    public static int parseQuantity(String text) {
        if (TextUtils.isEmpty(text)) {
            return INVALID_QUANTITY;
        }
        try {
            int quantity = Integer.parseInt(text);
            return (quantity >= 0 && quantity <= MAX_QUANTITY) ? quantity : INVALID_QUANTITY;
        } catch (NumberFormatException e) {
            return INVALID_QUANTITY;
        }
    }
}