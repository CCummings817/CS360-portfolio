package com.example.inventoryappproject_cummings;

import android.Manifest;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.telephony.SmsManager;
import android.text.TextUtils;
import android.util.Log;

import androidx.core.content.ContextCompat;

/**
 * Everything SMS-related in one place: checking permission, remembering
 * the alert phone number, and sending texts.
 *
 * Key rule: if the user denied SMS permission or never saved a number,
 * alerts are skipped quietly. The rest of the app keeps working and the
 * user is not nagged about a feature they turned down.
 */
public class SmsAlertHelper {

    private static final String TAG = "SmsAlertHelper";
    private static final String PREFS_NAME = "sms_alert_prefs";
    private static final String KEY_ALERT_PHONE = "alert_phone";

    private final Context appContext;

    public SmsAlertHelper(Context context) {
        this.appContext = context.getApplicationContext();
    }

    public boolean hasSmsPermission() {
        return ContextCompat.checkSelfPermission(appContext, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED;
    }

    /** The saved alert number, or an empty string if none has been saved. */
    public String getSavedPhone() {
        return getPrefs().getString(KEY_ALERT_PHONE, "");
    }

    /** Remembers the alert number so out-of-stock texts know where to go. */
    public void savePhone(String phone) {
        getPrefs().edit().putString(KEY_ALERT_PHONE, phone).apply();
    }

    /** Alerts only go out when permission is granted AND a number is saved. */
    public boolean canSendAlerts() {
        return hasSmsPermission() && !TextUtils.isEmpty(getSavedPhone());
    }

    /**
     * Texts the saved number that an item just ran out.
     *
     * @return true if a text was sent, false if alerts are off or sending failed
     */
    public boolean sendOutOfStockAlert(String itemName) {
        if (!canSendAlerts()) {
            return false; // Permission denied or no number: skip without bothering the user
        }
        String message = appContext.getString(R.string.sms_out_of_stock_message, itemName);
        return sendSms(getSavedPhone(), message);
    }

    /** Sends the test message from the SMS settings screen. */
    public boolean sendTestAlert(String phone) {
        if (!hasSmsPermission()) {
            return false;
        }
        return sendSms(phone, appContext.getString(R.string.sms_test_message));
    }

    private boolean sendSms(String phone, String message) {
        try {
            SmsManager smsManager = (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S)
                    ? appContext.getSystemService(SmsManager.class)
                    : SmsManager.getDefault();
            smsManager.sendTextMessage(phone, null, message, null, null);
            return true;
        } catch (SecurityException | IllegalArgumentException e) {
            // Permission revoked mid-session or a bad number. Log it and move on.
            Log.w(TAG, "SMS could not be sent", e);
            return false;
        } catch (UnsupportedOperationException e) {
            // Device without telephony (some tablets)
            Log.w(TAG, "SMS is not supported on this device", e);
            return false;
        }
    }

    private SharedPreferences getPrefs() {
        return appContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }
}