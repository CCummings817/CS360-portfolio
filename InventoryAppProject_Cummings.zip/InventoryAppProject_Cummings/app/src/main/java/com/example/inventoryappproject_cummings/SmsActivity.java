package com.example.inventoryappproject_cummings;

import android.Manifest;
import android.os.Bundle;
import android.util.Patterns;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

/**
 * SMS alert settings. Asks for the SEND_SMS permission, saves the phone
 * number alerts go to, and shows whether alerts are on, off, or denied.
 */
public class SmsActivity extends AppCompatActivity {

    private SmsAlertHelper smsAlertHelper;
    private TextView textStatusTitle;
    private TextView textStatusDetail;
    private Button buttonEnableSms;
    private TextInputLayout layoutPhone;
    private TextInputEditText editPhone;

    private boolean wasDenied = false;
    private boolean sendTestAfterGrant = false;

    // Shows the Android permission popup and handles the user's answer
    private final ActivityResultLauncher<String> requestSmsPermission =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), granted -> {
                wasDenied = !granted;
                updateStatus();
                if (granted && sendTestAfterGrant) {
                    sendTestAlert();
                }
                sendTestAfterGrant = false;
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_sms);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        smsAlertHelper = new SmsAlertHelper(this);
        MaterialToolbar toolbar = findViewById(R.id.toolbar);
        textStatusTitle = findViewById(R.id.textStatusTitle);
        textStatusDetail = findViewById(R.id.textStatusDetail);
        buttonEnableSms = findViewById(R.id.buttonEnableSms);
        Button buttonSendTest = findViewById(R.id.buttonSendTest);
        layoutPhone = findViewById(R.id.layoutPhone);
        editPhone = findViewById(R.id.editPhone);

        // Fill in the number saved last time
        editPhone.setText(smsAlertHelper.getSavedPhone());

        toolbar.setNavigationOnClickListener(v -> finish());

        buttonEnableSms.setOnClickListener(v -> {
            savePhoneIfValid();
            requestSmsPermission.launch(Manifest.permission.SEND_SMS);
        });

        // Always check permission before sending. If missing, ask first.
        buttonSendTest.setOnClickListener(v -> {
            if (smsAlertHelper.hasSmsPermission()) {
                sendTestAlert();
            } else {
                sendTestAfterGrant = true;
                requestSmsPermission.launch(Manifest.permission.SEND_SMS);
            }
        });

        updateStatus();
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Picks up changes if the user flipped the permission in Settings
        updateStatus();
    }

    @Override
    protected void onPause() {
        super.onPause();
        // Leaving the screen saves the number, no extra Save button needed
        savePhoneIfValid();
    }

    /** Saves the typed number if it looks like a phone number. Returns the result. */
    private boolean savePhoneIfValid() {
        String phone = InputValidator.clean(editPhone.getText());
        if (!Patterns.PHONE.matcher(phone).matches()) {
            return false;
        }
        smsAlertHelper.savePhone(phone);
        return true;
    }

    /** Updates the status card to match the current permission state. */
    private void updateStatus() {
        if (smsAlertHelper.hasSmsPermission()) {
            textStatusTitle.setText(R.string.status_on_title);
            textStatusTitle.setTextColor(ContextCompat.getColor(this, R.color.ok_green));
            textStatusDetail.setText(smsAlertHelper.getSavedPhone().isEmpty()
                    ? R.string.status_on_no_phone_detail : R.string.status_on_detail);
            buttonEnableSms.setText(R.string.btn_alerts_enabled);
            buttonEnableSms.setEnabled(false);
        } else if (wasDenied) {
            textStatusTitle.setText(R.string.status_denied_title);
            textStatusTitle.setTextColor(ContextCompat.getColor(this, R.color.alert_red));
            textStatusDetail.setText(R.string.status_denied_detail);
            buttonEnableSms.setText(R.string.btn_enable_sms);
            buttonEnableSms.setEnabled(true);
        } else {
            textStatusTitle.setText(R.string.status_off_title);
            textStatusTitle.setTextColor(ContextCompat.getColor(this, R.color.gray_text));
            textStatusDetail.setText(R.string.status_off_detail);
            buttonEnableSms.setText(R.string.btn_enable_sms);
            buttonEnableSms.setEnabled(true);
        }
    }

    /** Sends a test text to the typed number so the user knows alerts work. */
    private void sendTestAlert() {
        if (!savePhoneIfValid()) {
            layoutPhone.setError(getString(R.string.error_phone));
            return;
        }
        layoutPhone.setError(null);
        updateStatus(); // Number may have just been saved, refresh the card

        boolean sent = smsAlertHelper.sendTestAlert(smsAlertHelper.getSavedPhone());
        Toast.makeText(this, sent ? R.string.toast_test_sent : R.string.toast_test_failed,
                Toast.LENGTH_SHORT).show();
    }
}