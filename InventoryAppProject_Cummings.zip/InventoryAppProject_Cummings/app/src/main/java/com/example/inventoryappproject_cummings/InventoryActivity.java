package com.example.inventoryappproject_cummings;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

import java.util.List;

/**
 * Main screen: shows every inventory item from the database in a grid and
 * handles updating, editing, and deleting them. Also fires the SMS alert
 * when an item drops to zero.
 */
public class InventoryActivity extends AppCompatActivity
        implements InventoryAdapter.OnItemActionListener {

    private DatabaseHelper databaseHelper;
    private SmsAlertHelper smsAlertHelper;
    private InventoryAdapter adapter;
    private TextView textEmptyState;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_inventory);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        databaseHelper = DatabaseHelper.getInstance(this);
        smsAlertHelper = new SmsAlertHelper(this);
        textEmptyState = findViewById(R.id.textEmptyState);

        // Grid setup. Data gets loaded in onResume.
        adapter = new InventoryAdapter(this);
        RecyclerView recycler = findViewById(R.id.recyclerInventory);
        recycler.setLayoutManager(new LinearLayoutManager(this));
        recycler.setAdapter(adapter);

        // Toolbar: bell opens SMS settings, door icon logs out
        MaterialToolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setOnMenuItemClickListener(menuItem -> {
            if (menuItem.getItemId() == R.id.action_sms) {
                startActivity(new Intent(this, SmsActivity.class));
                return true;
            } else if (menuItem.getItemId() == R.id.action_logout) {
                logOut();
                return true;
            }
            return false;
        });

        ExtendedFloatingActionButton fabAddItem = findViewById(R.id.fabAddItem);
        fabAddItem.setOnClickListener(v ->
                startActivity(new Intent(this, AddItemActivity.class)));
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Reload every time we come back so new items from Add Item show up
        loadItems();
    }

    /** Read: pulls everything from the database into the grid. */
    private void loadItems() {
        List<InventoryItem> items = databaseHelper.getAllItems();
        adapter.setItems(items);
        updateEmptyState(items.isEmpty());
    }

    private void updateEmptyState(boolean isEmpty) {
        textEmptyState.setVisibility(isEmpty ? View.VISIBLE : View.GONE);
    }

    // ---------------------------------------------------------------------
    // Row actions (called by the adapter)
    // ---------------------------------------------------------------------

    /** Update: the + and - buttons. */
    @Override
    public void onQuantityChangeRequested(InventoryItem item, int newQuantity) {
        if (newQuantity < 0 || newQuantity > InputValidator.MAX_QUANTITY) {
            return;
        }
        int oldQuantity = item.getQuantity();

        if (databaseHelper.updateQuantity(item.getId(), newQuantity)) {
            item.setQuantity(newQuantity);
            adapter.refreshItem(item);
            alertIfJustRanOut(item, oldQuantity);
        } else {
            Toast.makeText(this, R.string.toast_update_failed, Toast.LENGTH_SHORT).show();
        }
    }

    /** Delete: asks first, since a delete can't be undone. */
    @Override
    public void onDeleteRequested(InventoryItem item) {
        new MaterialAlertDialogBuilder(this)
                .setTitle(R.string.dialog_delete_title)
                .setMessage(getString(R.string.dialog_delete_message, item.getName()))
                .setNegativeButton(R.string.btn_cancel, null)
                .setPositiveButton(R.string.btn_delete, (dialog, which) -> {
                    if (databaseHelper.deleteItem(item.getId())) {
                        adapter.removeItem(item);
                        updateEmptyState(adapter.getItemCount() == 0);
                    } else {
                        Toast.makeText(this, R.string.toast_update_failed, Toast.LENGTH_SHORT).show();
                    }
                })
                .show();
    }

    /** Update: tapping a row opens a dialog to change its name or quantity. */
    @Override
    public void onEditRequested(InventoryItem item) {
        View dialogView = getLayoutInflater().inflate(R.layout.dialog_edit_item, null);
        TextInputLayout layoutName = dialogView.findViewById(R.id.layoutEditName);
        TextInputLayout layoutQuantity = dialogView.findViewById(R.id.layoutEditQuantity);
        TextInputEditText editName = dialogView.findViewById(R.id.editEditName);
        TextInputEditText editQuantity = dialogView.findViewById(R.id.editEditQuantity);

        editName.setText(item.getName());
        editQuantity.setText(String.valueOf(item.getQuantity()));

        AlertDialog dialog = new MaterialAlertDialogBuilder(this)
                .setTitle(R.string.dialog_edit_title)
                .setView(dialogView)
                .setNegativeButton(R.string.btn_cancel, null)
                .setPositiveButton(R.string.btn_save, null) // Wired up below
                .show();

        // Set the Save click after show() so bad input keeps the dialog open
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String newName = InputValidator.clean(editName.getText());
            int newQuantity = InputValidator.parseQuantity(InputValidator.clean(editQuantity.getText()));

            layoutName.setError(newName.isEmpty() ? getString(R.string.error_item_name) : null);
            layoutQuantity.setError(newQuantity == InputValidator.INVALID_QUANTITY
                    ? getString(R.string.error_quantity) : null);
            if (newName.isEmpty() || newQuantity == InputValidator.INVALID_QUANTITY) {
                return;
            }

            int oldQuantity = item.getQuantity();
            if (databaseHelper.updateItem(item.getId(), newName, newQuantity)) {
                dialog.dismiss();
                loadItems(); // Full reload since a name change can change the sort order
                item.setQuantity(newQuantity);
                alertIfJustRanOut(item, oldQuantity);
            } else {
                Toast.makeText(this, R.string.toast_update_failed, Toast.LENGTH_SHORT).show();
            }
        });
    }

    // ---------------------------------------------------------------------
    // Helpers
    // ---------------------------------------------------------------------

    /**
     * Sends the out-of-stock text, but only when an item goes from having
     * stock to zero. If SMS is off, this quietly does nothing.
     */
    private void alertIfJustRanOut(InventoryItem item, int oldQuantity) {
        if (oldQuantity > 0 && item.isOutOfStock()
                && smsAlertHelper.sendOutOfStockAlert(item.getName())) {
            Toast.makeText(this, getString(R.string.toast_alert_sent, item.getName()),
                    Toast.LENGTH_SHORT).show();
        }
    }

    /** Back to the login screen, clearing the back stack. */
    private void logOut() {
        Intent intent = new Intent(this, LoginActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }
}