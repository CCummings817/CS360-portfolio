package com.example.inventoryappproject_cummings;

/**
 * One row in the inventory table: a database id, an item name, and how
 * many are on the shelf.
 */
public class InventoryItem {

    private final long id;
    private String name;
    private int quantity;

    public InventoryItem(long id, String name, int quantity) {
        this.id = id;
        this.name = name;
        this.quantity = quantity;
    }

    public long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public boolean isOutOfStock() {
        return quantity == 0;
    }
}