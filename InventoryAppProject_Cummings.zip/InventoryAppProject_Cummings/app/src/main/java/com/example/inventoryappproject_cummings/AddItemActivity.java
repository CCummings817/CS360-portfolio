package com.example.inventoryappproject_cummings;

import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

/**
 * Create: lets the user add a new item and its starting quantity to the
 * inventory table.
 */
public class AddItemActivity extends AppCompatActivity {

    private DatabaseHelper databaseHelper;
    private TextInputLayout layoutItemName;
    private TextInputLayout layoutQuantity;
    private TextInputEditText editItemName;
    private TextInputEditText editQuantity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_add_item);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        databaseHelper = DatabaseHelper.getInstance(this);
        layoutItemName = findViewById(R.id.layoutItemName);
        layoutQuantity = findViewById(R.id.layoutQuantity);
        editItemName = findViewById(R.id.editItemName);
        editQuantity = findViewById(R.id.editQuantity);

        MaterialToolbar toolbar = findViewById(R.id.toolbar);
        Button buttonSave = findViewById(R.id.buttonSave);
        Button buttonCancel = findViewById(R.id.buttonCancel);

        toolbar.setNavigationOnClickListener(v -> finish());
        buttonCancel.setOnClickListener(v -> finish());
        buttonSave.setOnClickListener(v -> saveItem());
    }

    /** Validates the form, then inserts the item and returns to the grid. */
    private void saveItem() {
        String name = InputValidator.clean(editItemName.getText());
        int quantity = InputValidator.parseQuantity(InputValidator.clean(editQuantity.getText()));

        // Show every problem at once instead of one at a time
        layoutItemName.setError(name.isEmpty() ? getString(R.string.error_item_name) : null);
        layoutQuantity.setError(quantity == InputValidator.INVALID_QUANTITY
                ? getString(R.string.error_quantity) : null);
        if (name.isEmpty() || quantity == InputValidator.INVALID_QUANTITY) {
            return;
        }

        if (databaseHelper.addItem(name, quantity) != -1) {
            Toast.makeText(this, getString(R.string.toast_item_added, name), Toast.LENGTH_SHORT).show();
            finish(); // The grid reloads itself in onResume
        } else {
            Toast.makeText(this, R.string.toast_update_failed, Toast.LENGTH_SHORT).show();
        }
    }
}