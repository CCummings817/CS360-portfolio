package com.example.inventoryappproject_cummings;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

/**
 * Owns the Sightline SQLite database.
 *
 * Two tables live here:
 *   users     - login accounts (username plus a salted password hash)
 *   inventory - every stocked item and how many are on the shelf
 *
 * The database file is stored on the device, so accounts and inventory
 * survive the app being closed or the phone restarting.
 */
public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "sightline.db";
    private static final int DATABASE_VERSION = 1;

    // Users table
    private static final String TABLE_USERS = "users";
    private static final String COL_USER_ID = "_id";
    private static final String COL_USERNAME = "username";
    private static final String COL_PASSWORD_HASH = "password_hash";
    private static final String COL_SALT = "salt";

    // Inventory table
    private static final String TABLE_INVENTORY = "inventory";
    private static final String COL_ITEM_ID = "_id";
    private static final String COL_ITEM_NAME = "name";
    private static final String COL_QUANTITY = "quantity";

    // One shared instance so every screen talks to the same connection
    private static DatabaseHelper instance;

    public static synchronized DatabaseHelper getInstance(Context context) {
        if (instance == null) {
            // Application context avoids leaking whichever Activity asked first
            instance = new DatabaseHelper(context.getApplicationContext());
        }
        return instance;
    }

    private DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // COLLATE NOCASE means "Carrie" and "carrie" count as the same username
        db.execSQL("CREATE TABLE " + TABLE_USERS + " ("
                + COL_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COL_USERNAME + " TEXT NOT NULL UNIQUE COLLATE NOCASE, "
                + COL_PASSWORD_HASH + " TEXT NOT NULL, "
                + COL_SALT + " TEXT NOT NULL)");

        // CHECK constraint is a last line of defense against negative stock
        db.execSQL("CREATE TABLE " + TABLE_INVENTORY + " ("
                + COL_ITEM_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COL_ITEM_NAME + " TEXT NOT NULL, "
                + COL_QUANTITY + " INTEGER NOT NULL DEFAULT 0 CHECK (" + COL_QUANTITY + " >= 0))");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Only one schema version exists so far. A real release would migrate
        // data here instead of dropping it.
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_INVENTORY);
        onCreate(db);
    }

    // ---------------------------------------------------------------------
    // Users
    // ---------------------------------------------------------------------

    /** Returns true if an account with this username is already saved. */
    public boolean usernameExists(String username) {
        SQLiteDatabase db = getReadableDatabase();
        try (Cursor cursor = db.query(TABLE_USERS, new String[]{COL_USER_ID},
                COL_USERNAME + " = ?", new String[]{username},
                null, null, null)) {
            return cursor.moveToFirst();
        }
    }

    /**
     * Saves a new account. The plain password is never stored, only its hash.
     *
     * @return true if the account was created, false if the insert failed
     *         (for example, the username was taken)
     */
    public boolean createUser(String username, String password) {
        String salt = PasswordHasher.generateSalt();

        ContentValues values = new ContentValues();
        values.put(COL_USERNAME, username);
        values.put(COL_PASSWORD_HASH, PasswordHasher.hash(password, salt));
        values.put(COL_SALT, salt);

        return getWritableDatabase().insert(TABLE_USERS, null, values) != -1;
    }

    /** Returns true if the username exists and the password matches it. */
    public boolean checkLogin(String username, String password) {
        SQLiteDatabase db = getReadableDatabase();
        try (Cursor cursor = db.query(TABLE_USERS,
                new String[]{COL_PASSWORD_HASH, COL_SALT},
                COL_USERNAME + " = ?", new String[]{username},
                null, null, null)) {

            if (!cursor.moveToFirst()) {
                return false; // No such user
            }
            String storedHash = cursor.getString(cursor.getColumnIndexOrThrow(COL_PASSWORD_HASH));
            String salt = cursor.getString(cursor.getColumnIndexOrThrow(COL_SALT));
            return PasswordHasher.matches(password, salt, storedHash);
        }
    }

    // ---------------------------------------------------------------------
    // Inventory (Create, Read, Update, Delete)
    // ---------------------------------------------------------------------

    /** Read: every item, sorted alphabetically for the grid. */
    public List<InventoryItem> getAllItems() {
        List<InventoryItem> items = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();

        try (Cursor cursor = db.query(TABLE_INVENTORY, null, null, null, null, null,
                COL_ITEM_NAME + " COLLATE NOCASE ASC")) {

            int idIndex = cursor.getColumnIndexOrThrow(COL_ITEM_ID);
            int nameIndex = cursor.getColumnIndexOrThrow(COL_ITEM_NAME);
            int qtyIndex = cursor.getColumnIndexOrThrow(COL_QUANTITY);

            while (cursor.moveToNext()) {
                items.add(new InventoryItem(
                        cursor.getLong(idIndex),
                        cursor.getString(nameIndex),
                        cursor.getInt(qtyIndex)));
            }
        }
        return items;
    }

    /** Create: adds an item and returns its new row id, or -1 on failure. */
    public long addItem(String name, int quantity) {
        ContentValues values = new ContentValues();
        values.put(COL_ITEM_NAME, name);
        values.put(COL_QUANTITY, quantity);
        return getWritableDatabase().insert(TABLE_INVENTORY, null, values);
    }

    /** Update: changes both the name and quantity of one item. */
    public boolean updateItem(long itemId, String name, int quantity) {
        ContentValues values = new ContentValues();
        values.put(COL_ITEM_NAME, name);
        values.put(COL_QUANTITY, quantity);
        return updateRow(itemId, values);
    }

    /** Update: changes only the quantity (used by the +/- buttons). */
    public boolean updateQuantity(long itemId, int quantity) {
        ContentValues values = new ContentValues();
        values.put(COL_QUANTITY, quantity);
        return updateRow(itemId, values);
    }

    /** Delete: removes one item for good. */
    public boolean deleteItem(long itemId) {
        int rowsDeleted = getWritableDatabase().delete(TABLE_INVENTORY,
                COL_ITEM_ID + " = ?", new String[]{String.valueOf(itemId)});
        return rowsDeleted > 0;
    }

    // Shared by both update methods so the WHERE clause lives in one place
    private boolean updateRow(long itemId, ContentValues values) {
        int rowsUpdated = getWritableDatabase().update(TABLE_INVENTORY, values,
                COL_ITEM_ID + " = ?", new String[]{String.valueOf(itemId)});
        return rowsUpdated > 0;
    }
}